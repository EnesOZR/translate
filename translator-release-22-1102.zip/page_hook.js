/**
 * Sayfa dünyası (MAIN world) köprüsü - Translator & Görev Otomasyonu
 *
 * TodoList'te çoklu açma (Alt + N) sırasında sitenin kendi window.open(_blank) çağrılarını yakalar ve
 * eklentiye iletir; sekmeler arka plandan chrome.tabs.create ile açılır. Böylece Chrome'un pop-up
 * engelleyicisi (tek kullanıcı hareketi = tek pop-up) çoklu sekme açılmasını engelleyemez.
 *
 * Yalnızca content.js "silahlandırdığında" (kısa bir süre) ve aynı kökenli (same-origin) adreslerde devreye girer;
 * normal tıklamalarda window.open aynen çalışır.
 */
(function () {
  'use strict';

  if (window.__trOpenHooked) return;
  if (!/^(?:gkm\.oppo\.com|localhost|127\.0\.0\.1)$/i.test(location.hostname)) return;
  window.__trOpenHooked = true;

  const nativeOpen = window.open;
  let armedUntil = 0;

  window.addEventListener('__tr_arm_open', function (e) {
    var ms = 8000;
    try { ms = Number(JSON.parse(e.detail).ms) || ms; } catch (err) {}
    armedUntil = Date.now() + ms;
  });

  window.open = function (url, target) {
    try {
      var isBlankTarget = target === undefined || target === null || target === '' || target === '_blank';
      if (Date.now() < armedUntil && url && isBlankTarget) {
        var abs = new URL(String(url), window.location.href);
        if (abs.origin === window.location.origin) {
          window.dispatchEvent(new CustomEvent('__tr_open_tab', { detail: JSON.stringify({ url: abs.href }) }));
          return null;
        }
      }
    } catch (err) {}
    return nativeOpen.apply(this, arguments);
  };
})();
