/* Translator - çeviri belleği çekirdeği (content.js <tm-align> bloğundan üretildi, elle düzenlemeyin) */
(function () {
  'use strict';

  const TM_STORAGE_KEY = 'tr_tm_v1';
  const TM_MAX_ENTRIES = 20000;

  function tmNormalize(s) {
    return String(s || '')
      .replace(/[​-‍⁠﻿]/g, '')
      .replace(/：/g, ':').replace(/（/g, '(').replace(/）/g, ')').replace(/[“”]/g, '"').replace(/[‘’]/g, "'")
      .replace(/\s+/g, ' ').trim();
  }

  // Güvenli kalıp anahtarı: yalnızca model/parça kodları ("@") ve sayılar ("#") değişkendir.
  // "OPPO A6 Pro 5G ..." ile "OPPO A5 Pro 5G ..." aynı kalıptır; kelime farkı olan satırlar ASLA eşleşmez
  // (kelime benzerliğine dayalı bulanık eşleşme anlamı tersine çevirebilir: "supports" / "does not support").
  const TM_CODE_RE = /\b[A-Z][A-Za-z]{0,3}\d{1,5}[A-Za-z]{0,2}\+?(?![\w])/g;
  function tmTemplate(s) {
    const nums = [], codes = [];
    const key = tmNormalize(s)
      .replace(TM_CODE_RE, (m) => { if (/[a-z]{3}/.test(m)) return m; codes.push(m); return '@'; })
      .replace(/\d+(?:[.,]\d+)*/g, (m) => { nums.push(m); return '#'; });
    return { key, nums, codes };
  }

  // Belleğe girecek çiftin güvenlik denetimi. Sorun yoksa '' döner, varsa ret nedeni (arayüzde gösterilir).
  function tmPairCheck(en, tr) {
    if (!en || !tr) return 'Boş kaynak veya çeviri';
    if (/[⟦⟧]/.test(tr)) return 'Çeviride kalkan işareti kalmış';
    const norm = (n) => n.replace(/[.,](?=\d{3}\b)/g, '');
    const trNums = new Set((tr.match(/\d+(?:[.,]\d+)*/g) || []).map(norm));
    const lost = (en.match(/\d+(?:[.,]\d+)*/g) || []).map(norm).filter(n => !trNums.has(n) && !trNums.has(n.replace(',', '.')) && !trNums.has(n.replace('.', ',')));
    if (lost.length) return `Sayı kaybı: ${lost.slice(0, 3).join(', ')}`;
    const lostCodes = (en.match(TM_CODE_RE) || []).filter(c => !/[a-z]{3}/.test(c) && !tr.includes(c));
    if (lostCodes.length) return `Model/kod değişmiş: ${lostCodes.slice(0, 3).join(', ')}`;
    const enWords = (tr.match(/\b(the|and|of|to|is|are|with|for|from|this|that|when|your|you|will|can|not|be|or|on|in|by|it)\b/gi) || []).length;
    if (enWords >= 2) return 'Çeviride İngilizce kalıntı';
    const rep = tr.match(/(^|[^\p{L}])(\p{L}{3,})\s+\2(?!\p{L})/u);
    if (rep && !/(\b\w{3,}\b)\W+\1\b/i.test(en)) return `Kelime tekrarı: "${rep[2]} ${rep[2]}"`;
    return '';
  }
  function tmPairOk(en, tr) { return tmPairCheck(en, tr) === ''; }

  // Güvenli birleştirme: mevcut girdi silinmez. Aynı çeviri -> yineleme (onay sayısı yalnızca yeni makaleden artar),
  // farklı çeviri -> daha çok onaylı olan kalır, eşitse MEVCUT (tarayıcıda öğrenilmiş) kalır.
  // Dönüş: { added, duplicates, conflictsKept, conflictsReplaced, rejected: [{en, tr, reason, article}] }
  function tmMergeCandidates(entries, candidates) {
    const stats = { added: 0, duplicates: 0, conflictsKept: 0, conflictsReplaced: 0, rejected: [] };
    for (const c of candidates || []) {
      const en = tmNormalize(c.en), tr = tmNormalize(c.tr);
      const reason = tmPairCheck(en, tr);
      if (reason) { stats.rejected.push({ en, tr, reason, article: c.article || '' }); continue; }
      const n = Math.max(1, Number(c.n) || 1);
      const cur = entries[en];
      if (!cur) { entries[en] = { tr, n, a: c.article ? [c.article] : [], src: c.src || 'import' }; stats.added++; continue; }
      if (cur.tr === tr) {
        if (c.article && !cur.a.includes(c.article)) { cur.n += 1; cur.a = [...cur.a, c.article].slice(-5); }
        stats.duplicates++;
        continue;
      }
      if (n > (cur.n || 1)) { entries[en] = { ...cur, tr, n, a: c.article ? [c.article] : cur.a, src: c.src || 'import' }; stats.conflictsReplaced++; }
      else stats.conflictsKept++;
    }
    return stats;
  }

  // Hizalamada çapa: sayılar, model kodları, marka/teknoloji adları (çeviride aynen kalırlar)
  function tmAnchors(s) {
    const found = String(s).match(/\d+(?:[.,]\d+)*|\b[A-Z][A-Za-z0-9+]*\d[A-Za-z0-9+]*\b|\b(?:OPPO|OnePlus|realme|ColorOS|HeyTap|Google|Android|iPhone|iOS|eSIM|SIM|NFC|AI|USB|Bluetooth|Hasselblad)\b/g) || [];
    return new Set(found.map(x => x.replace(/[.,](?=\d{3}\b)/g, '')));
  }

  function tmSplitLines(text) {
    return String(text || '').split(/\n+/).map(tmNormalize).filter(l => l.length > 1);
  }

  function tmPairCost(en, tr) {
    const ratio = tr.length / Math.max(1, en.length);
    let cost = Math.abs(Math.log(ratio / 1.1)) * 2;
    const a = tmAnchors(en), b = tmAnchors(tr);
    if (a.size || b.size) {
      const inter = [...a].filter(x => b.has(x)).length;
      cost += (1 - inter / Math.max(a.size, b.size)) * 3;
    }
    const mark = /^(?:[IVX]{1,4}|[ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ]|\d{1,2})[.、)]/;
    const mEn = en.match(mark), mTr = tr.match(mark);
    if (!!mEn !== !!mTr || (mEn && mTr && mEn[0] !== mTr[0])) cost += 1.5;
    return cost;
  }

  // EN ve TR satırlarını sırayı koruyarak hizalar (eksik/fazla satır serbest); yalnızca güvenilir 1-1 çiftleri döndürür
  function tmAlign(enLines, trLines, maxCost = 1.6) {
    const n = enLines.length, m = trLines.length;
    if (!n || !m || n * m > 250000) return [];
    const GAP = 2.2;
    const dp = Array.from({ length: n + 1 }, () => new Float64Array(m + 1));
    const bt = Array.from({ length: n + 1 }, () => new Uint8Array(m + 1));
    for (let i = 1; i <= n; i++) { dp[i][0] = i * GAP; bt[i][0] = 1; }
    for (let j = 1; j <= m; j++) { dp[0][j] = j * GAP; bt[0][j] = 2; }
    for (let i = 1; i <= n; i++) {
      for (let j = 1; j <= m; j++) {
        const c = dp[i - 1][j - 1] + tmPairCost(enLines[i - 1], trLines[j - 1]);
        const u = dp[i - 1][j] + GAP, l = dp[i][j - 1] + GAP;
        if (c <= u && c <= l) { dp[i][j] = c; bt[i][j] = 0; } else if (u <= l) { dp[i][j] = u; bt[i][j] = 1; } else { dp[i][j] = l; bt[i][j] = 2; }
      }
    }
    const pairs = [];
    for (let i = n, j = m; i > 0 || j > 0;) {
      if (i > 0 && j > 0 && bt[i][j] === 0) {
        const en = enLines[i - 1], tr = trLines[j - 1];
        if (tmPairCost(en, tr) <= maxCost) pairs.push([en, tr]);
        i--; j--;
      } else if (i > 0 && (j === 0 || bt[i][j] === 1)) i--;
      else j--;
    }
    // Güvenlik: kaynak İngilizce olmalı, hedef farklı ve Türkçe olmalı (çevrilmemiş satır belleğe girmez)
    return pairs.reverse().filter(([en, tr]) =>
      /[A-Za-z]{2}/.test(en) && en !== tr && !/[çşğüöıÇŞĞÜÖİ]/.test(en) &&
      (/[çşğüöıÇŞĞÜÖİ]/.test(tr) || tr.length < 24) && !isAlreadyTurkishLine(en));
  }

  function isAlreadyTurkishLine(s) { return /[çşğüöıÇŞĞÜÖİ]/.test(s); }

  // Türkçe-Türkçe benzerlik (karakter ikilisi Dice katsayısı, 0..1)
  function tmSimilarity(a, b) {
    const bi = (s) => { const m = new Map(); const t = s.toLowerCase(); for (let i = 0; i < t.length - 1; i++) { const g = t.slice(i, i + 2); m.set(g, (m.get(g) || 0) + 1); } return m; };
    const x = bi(a), y = bi(b);
    let inter = 0, tot = 0;
    for (const [g, c] of x) { inter += Math.min(c, y.get(g) || 0); tot += c; }
    for (const c of y.values()) tot += c;
    return tot ? (2 * inter) / tot : 0;
  }

  // Aynı dildeki iki satır listesini sırayla hizalar; yalnızca benzerliği eşiği geçen çiftler
  function tmAlignSimilar(aLines, bLines, minSim = 0.45) {
    const n = aLines.length, m = bLines.length;
    if (!n || !m || n * m > 250000) return [];
    const GAP = 0.6;
    const dp = Array.from({ length: n + 1 }, () => new Float64Array(m + 1));
    const bt = Array.from({ length: n + 1 }, () => new Uint8Array(m + 1));
    for (let i = 1; i <= n; i++) { dp[i][0] = i * GAP; bt[i][0] = 1; }
    for (let j = 1; j <= m; j++) { dp[0][j] = j * GAP; bt[0][j] = 2; }
    for (let i = 1; i <= n; i++) {
      for (let j = 1; j <= m; j++) {
        const c = dp[i - 1][j - 1] + (1 - tmSimilarity(aLines[i - 1], bLines[j - 1]));
        const u = dp[i - 1][j] + GAP, l = dp[i][j - 1] + GAP;
        if (c <= u && c <= l) { dp[i][j] = c; bt[i][j] = 0; } else if (u <= l) { dp[i][j] = u; bt[i][j] = 1; } else { dp[i][j] = l; bt[i][j] = 2; }
      }
    }
    const pairs = [];
    for (let i = n, j = m; i > 0 || j > 0;) {
      if (i > 0 && j > 0 && bt[i][j] === 0) {
        if (tmSimilarity(aLines[i - 1], bLines[j - 1]) >= minSim) pairs.push([aLines[i - 1], bLines[j - 1]]);
        i--; j--;
      } else if (i > 0 && (j === 0 || bt[i][j] === 1)) i--;
      else j--;
    }
    return pairs.reverse();
  }

  // Köprülü hizalama: EN -> makine çevirisi (aynı sıra) -> insan son metni (Türkçe benzerlik).
  // İnsan satırı, o İngilizce satırın makine çevirisinden türemiş olmalı; alakasız satır eşleşemez.
  // Makine çevirisi yoksa yalnızca çok güvenilir doğrudan hizalama kullanılır.
  function tmAlignBridged(enText, mtText, humanText) {
    const en = tmSplitLines(enText), hu = tmSplitLines(humanText);
    const mt = tmSplitLines(mtText);
    if (!mt.length) return tmAlign(en, hu, 1.0);
    const enMt = tmAlign(en, mt, 2.2);
    const mtHu = new Map(tmAlignSimilar(mt, hu));
    const out = [];
    for (const [e, m] of enMt) { const h = mtHu.get(m); if (h) out.push([e, h]); }
    return out;
  }

  // Bellek girdisi: { tr, n (kaç makalede onaylandı), a (son makale anahtarları) }
  function tmAddPairs(entries, pairs, articleKey) {
    for (const [en, tr] of pairs) {
      if (!tmPairOk(en, tr)) continue; // hatalı/eksik çeviri belleğe girmez
      const cur = entries[en];
      if (!cur) { entries[en] = { tr, n: 1, a: articleKey ? [articleKey] : [] }; continue; }
      const seen = articleKey && cur.a.includes(articleKey);
      // Aynı makalede düzenleme sürüyorsa son hali geçerli; farklı makalede aynı çeviri onay sayısını artırır
      if (seen) { cur.tr = tr; continue; }
      if (cur.tr === tr) cur.n++;
      else if (cur.n <= 1) cur.tr = tr; // tek onaylı eski çeviri, daha yeni insan kararıyla değişir
      if (articleKey) cur.a = [...cur.a, articleKey].slice(-5);
    }
    return entries;
  }
  
  globalThis.TRTM = { tmNormalize, tmTemplate, tmPairCheck, tmPairOk, tmMergeCandidates, tmAddPairs, tmSplitLines, tmAlign, tmAlignBridged };
})();
