/**
 * MERKEZİ TERMİNOLOJİ (OPPO / ColorOS) — tek yerden yönetilir.
 * Eklenti bu dosyayı içerik betiğinden önce yükler; kod terimleri buradan okur. Terim eklemek/değiştirmek için
 * yalnızca bu dosya düzenlenir ve eklenti yeniden derlenir.
 *
 *  keep    : Aynen korunan ürün / özellik / marka adları (çevrilmez). "re:" ile başlayan girdi düzenli ifadedir.
 *  ui      : ColorOS arayüz adları. Köşeli parantez içinde ([Settings]) ve menü yolunda (Settings > Apps) resmî
 *            karşılıkla yazılır; serbest cümle içinde DEĞİŞTİRİLMEZ (bağlam belirsiz).
 *  heading : Bölüm başlıkları. Satırın/hücrenin TAMAMI bu başlıksa (bölüm numarası ve iki nokta hariç) uygulanır.
 *  segment : Satırın tamamı bu ifadeyse kullanılan sabit çeviri (tablo hücresi, etiket).
 */
globalThis.TR_TERMINOLOGY = {
  version: '2026-11-03',

  keep: [
    'Zero-Feel Crease', 'Auto-Smoothing Flex Glass', 'Free-Flow Window', 'AI Mind Space', 'AI Recording', 'AI Painter',
    'Sound Focus', 'ProXDR', 'NetworkBoost', 'AI LinkBoost', 'Fold Antenna Matrix', 'Unisoc', 'HeyTap Account', 'HeyTap',
    'R-Edition', 'Flashing Tool', 'Flash Tool', 'Clone Phone', 'Hasselblad Ultra Clear',
    're:Hasselblad(?:\\s+(?:(?:200MP\\s+)?(?:Natural\\s+Color|Image\\s+Tone|Master\\s+Camera(?:\\s+System)?)))?',
    're:SUPERVOOC(?:TM|™)?', 're:AIRVOOC(?:TM|™)?', 're:Flashing\\s+Tool(?:\\s+6(?:\\.0)?)?', 're:NetworkBoost(?:\\s+Chip\\s+S\\d)?',
    're:Snapdragon®?\\s+\\d+(?:\\s+Elite)?(?:\\s+Gen\\s+\\d+)?', 're:Qualcomm®?\\s+Oryon™?', 're:realme\\s+UI(?:\\s+\\d+(?:\\.\\d+)?)?'
  ],

  ui: {
    'Settings': 'Ayarlar', 'Display & Brightness': 'Ekran ve Parlaklık', 'More': 'Daha Fazla', 'Camera': 'Kamera',
    'About Phone': 'Telefon Hakkında', 'About device': 'Cihaz Hakkında', 'System settings': 'Sistem Ayarları', 'Additional settings': 'Ek Ayarlar',
    'Battery': 'Pil', 'Notifications & Status Bar': 'Bildirimler ve Durum Çubuğu', 'Sound & Vibration': 'Ses ve Titreşim',
    'SIM Card & Mobile Data': 'SIM Kart ve Mobil Veri', 'Wi-Fi': 'Wi-Fi', 'Bluetooth': 'Bluetooth', 'Apps': 'Uygulamalar',
    'App management': 'Uygulama yönetimi', 'Security': 'Güvenlik', 'Privacy': 'Gizlilik', 'Security and Privacy': 'Güvenlik ve Gizlilik',
    'Wallpaper & Style': 'Duvar Kağıdı ve Stil', 'Home Screen & Lock Screen': 'Ana Ekran ve Kilit Ekranı', 'Refresh Rate': 'Yenileme Hızı',
    'Display': 'Ekran', 'Brightness': 'Parlaklık', 'Network & Internet': 'Ağ ve İnternet', 'Special Features': 'Özel Özellikler',
    'Smart Sidebar': 'Akıllı Kenar Çubuğu', 'Eye Comfort': 'Göz Rahatlığı', 'Eye Care': 'Göz Rahatlığı',
    'Software Update': 'Yazılım Güncelleme', 'Storage': 'Depolama', 'Storage usage': 'Depolama kullanımı', 'Clear data': 'Verileri temizle',
    'Clear cache': 'Önbelleği temizle', 'Connection & sharing': 'Bağlantı ve paylaşım', 'Accessibility': 'Erişilebilirlik',
    'Date & time': 'Tarih ve saat', 'Language & region': 'Dil ve bölge', 'Back up and reset': 'Yedekleme ve sıfırlama',
    'Reset phone': 'Telefonu sıfırla', 'Find My Device': 'Cihazımı Bul'
  },

  heading: {
    'Problem Description': 'Sorun Açıklaması', 'Problem description': 'Sorun Açıklaması',
    'Involved Models': 'İlgili Modeller', 'Models Involved': 'İlgili Modeller', 'Involved models': 'İlgili Modeller',
    'Cause Analysis': 'Sebep Analizi', 'Reason Analysis': 'Sebep Analizi', 'Cause of the Problem': 'Sorunun Nedeni',
    'Solution': 'Çözüm', 'Solutions': 'Çözümler', 'Background': 'Arka Plan', 'Background Overview': 'Arka Plana Genel Bakış',
    'Operation Path': 'İşlem Yolu', 'Function Introduction': 'İşlev Tanıtımı', 'Usage Method': 'Kullanım Yöntemi',
    'Scope of involvement': 'Etki Kapsamı', 'Scope of impact': 'Etki Kapsamı', 'Impact scope': 'Etki Kapsamı',
    'Note': 'Not', 'Notes': 'Notlar', 'Related article': 'İlgili makale', 'Related articles': 'İlgili makaleler',
    'Knowledge Ownership': 'Bilgi Sahipliği', 'Knowledge Update Points': 'Bilgi Güncelleme Noktaları', 'Knowledge update point': 'Bilgi Güncelleme Noktası',
    'FAQ': 'SSS', 'FAQs': 'SSS', 'Countermeasures': 'Karşı Önlemler',
    'Script': 'Konuşma Metni (Örnek Yanıt)', 'Reference Script': 'Konuşma Metni (Örnek Yanıt)', 'Reference caliber': 'Konuşma Metni (Örnek Yanıt)'
  },

  segment: {
    'Not Supported': 'Desteklenmiyor', 'Supported': 'Destekleniyor', 'Not supported': 'Desteklenmiyor',
    'Ultra Wide Mode': 'Ultra Geniş Mod', 'Sense of Space': 'Mekân Hissi', 'Tally selection': 'Talep Sınıflandırması (Tally)',
    'Motion Photo': 'Hareketli Fotoğraf',
    '1510A Superconducting magnetic Linear Speaker': '1510A Süper İletken Manyetik Doğrusal Hoparlör',
    '1510X Superconducting Magnetic Linear Speaker': '1510X Süper İletken Manyetik Doğrusal Hoparlör'
  }
};
